---
name: '#1 Landing Page'
about: Issue for the landing page requirement
title: User can see the home page
labels: ''
assignees: ''
---

A user should be able to:

- [ ] Navigate to the home page (`/`)
- [ ] See all placeholder data from mockup

For more information on accessing the design assets, see the [Design Assets section in the README](https://github.com/OpenClassrooms-Student-Center/ArgentBank-website#design-assets).
